import HeroSection from "@/app/components/solusi/HeroSection";
import BestSolutionsSection from "@/app/components/solusi/BestSolutionsSection";
import WhyChoose from "@/app/components/solusi/WhyChoose";
import IndustrySection from "@/app/components/solusi/IndustrySection";

import { getCmsPage } from "@/app/services/cms";

export default async function Page({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  const page = await getCmsPage("solutions", locale);

  const sections = page?.sections ?? {};

  return (
    <>
      <HeroSection
        content={sections.Solutions?.hero}
        locale={locale}
      />

      <BestSolutionsSection
        content={sections.Solutions?.bestSolutions}
      />

      <WhyChoose
        content={sections.WhyChoose}
        locale={locale}
      />

      <IndustrySection
        content={sections.SolutionsIndustry}
        locale={locale}
      />
    </>
  );
}